"""Turns a validated DesignSpec + confirmed fields into trusted HTML/CSS.

The model never emits markup: every string is escaped, every colour/font/size is
validated by the schema before it reaches this module.
"""
from __future__ import annotations

import html as _html
from dataclasses import dataclass, field
from typing import Optional

from ...config import FONT_DIR
from ...schemas import BlankOptions, DesignSpec, EventFields
from .layouts import PAGE_H, PAGE_W, geometry, signatory_rects

FONT_FACES = {
    "lora": [("Lora-Variable.ttf", "normal", "400 700"), ("Lora-Italic-Variable.ttf", "italic", "400 700")],
    "inter": [("Inter-Regular.otf", "normal", "400"), ("Inter-Medium.otf", "normal", "500"),
              ("Inter-SemiBold.otf", "normal", "600"), ("Inter-Bold.otf", "normal", "700")],
    "poppins": [("Poppins-Regular.ttf", "normal", "400"), ("Poppins-Medium.ttf", "normal", "500"),
                ("Poppins-Bold.ttf", "normal", "700")],
}
FALLBACK_STACK = {"lora": "serif", "inter": "sans-serif", "poppins": "sans-serif"}
BASE = "http://bp.local"


@dataclass
class PageData:
    name: Optional[str] = None
    organisation: Optional[str] = None
    award: Optional[str] = None
    row_id: Optional[str] = None


@dataclass
class RenderContext:
    spec: DesignSpec
    event: EventFields
    pages: list[PageData]
    blank: Optional[BlankOptions] = None  # set => blank-name mode
    asset_urls: dict[str, str] = field(default_factory=dict)  # asset_id -> url


def esc(s: str) -> str:
    return _html.escape(s or "", quote=True)


def render_body_text(spec: DesignSpec, event: EventFields) -> str:
    t = event.wording.strip() or spec.body_text
    return (t.replace("{event_name}", event.event_name)
             .replace("{organisation}", event.organisation)
             .replace("{event_date}", event.event_date))


def used_fonts(spec: DesignSpec) -> list[str]:
    return sorted({spec.fonts.heading, spec.fonts.body, spec.fonts.name})


def font_files(spec: DesignSpec) -> dict[str, "Path"]:
    out = {}
    for key in used_fonts(spec):
        for fn, _, _ in FONT_FACES[key]:
            out[fn] = FONT_DIR / fn
    return out


def expected_fixed_texts(ctx: RenderContext) -> list[dict]:
    """Fixed strings that must appear on every page (label, text)."""
    s, e = ctx.spec, ctx.event
    out = []
    if e.organisation:
        out.append({"label": "organisation", "text": e.organisation})
    if e.cert_type:
        out.append({"label": "certificate type", "text": e.cert_type})
    if s.preamble_text:
        out.append({"label": "preamble", "text": s.preamble_text})
    body = render_body_text(s, e)
    if body:
        out.append({"label": "award wording", "text": body})
    for i, sg in enumerate(e.signatories):
        if sg.name:
            out.append({"label": f"signatory {i+1} name", "text": sg.name})
        if sg.title:
            out.append({"label": f"signatory {i+1} title", "text": sg.title})
    if ctx.blank:
        for fld, pol in ctx.blank.optional_fields.items():
            if pol.mode == "fixed" and pol.fixed_text:
                out.append({"label": f"fixed {fld}", "text": pol.fixed_text})
    return out


def _rect_style(r) -> str:
    x, y, w, h = r
    return f"left:{x:.3f}mm;top:{y:.3f}mm;width:{w:.3f}mm;height:{h:.3f}mm;"


def _font_css(spec: DesignSpec) -> str:
    css = []
    for key in used_fonts(spec):
        for fn, style, weight in FONT_FACES[key]:
            css.append(
                f"@font-face{{font-family:'BP-{key}';src:url('{BASE}/fonts/{fn}');"
                f"font-style:{style};font-weight:{weight};font-display:block;}}"
            )
    return "\n".join(css)


def _decor(spec: DesignSpec) -> str:
    p = spec.palette
    d = []
    lid = spec.layout_id
    bw = spec.border_mm
    if lid == "formal" and bw > 0:
        d.append(f'<div class="decor" data-decor="1" data-frame="1" style="left:6mm;top:6mm;width:285mm;height:198mm;'
                 f'border:{bw}mm solid {p.primary};box-sizing:border-box;"></div>')
        d.append(f'<div class="decor" data-decor="1" data-frame="1" style="left:9.5mm;top:9.5mm;width:278mm;height:191mm;'
                 f'border:0.3mm solid {p.accent};box-sizing:border-box;"></div>')
    elif lid == "academic":
        d.append(f'<div class="decor" data-decor="1" style="left:0;top:0;width:10mm;height:{PAGE_H}mm;background:{p.primary};"></div>')
        d.append(f'<div class="decor" data-decor="1" style="left:10mm;top:0;width:{max(bw,0.5):.2f}mm;height:{PAGE_H}mm;background:{p.accent};"></div>')
    elif lid == "event":
        d.append(f'<div class="decor" data-decor="1" style="left:0;top:0;width:{PAGE_W}mm;height:5mm;background:{p.primary};"></div>')
        d.append(f'<div class="decor" data-decor="1" style="left:0;top:{PAGE_H-5}mm;width:{PAGE_W}mm;height:5mm;background:{p.accent};"></div>')
    o = spec.ornament
    if o == "corners":
        w = max(bw, 0.6)
        for (x, y, bt, bl) in ((13, 13, 1, 1), (PAGE_W - 29, 13, 1, 0), (13, PAGE_H - 29, 0, 1), (PAGE_W - 29, PAGE_H - 29, 0, 0)):
            sides = []
            sides.append(f"border-top:{w}mm solid {p.accent};" if bt else f"border-bottom:{w}mm solid {p.accent};")
            sides.append(f"border-left:{w}mm solid {p.accent};" if bl else f"border-right:{w}mm solid {p.accent};")
            d.append(f'<div class="decor" data-decor="1" style="left:{x}mm;top:{y}mm;width:16mm;height:16mm;box-sizing:border-box;{"".join(sides)}"></div>')
    elif o == "rule":
        d.append(f'<div class="decor" data-decor="1" style="left:108.5mm;top:64.2mm;width:80mm;height:0.6mm;background:{p.accent};"></div>')
    elif o == "band":
        d.append(f'<div class="decor" data-decor="1" style="left:0;top:{PAGE_H-12}mm;width:{PAGE_W}mm;height:2mm;background:{p.accent};"></div>')
    return "".join(d)


def _css(ctx: RenderContext) -> str:
    s = ctx.spec
    p = s.palette
    f = s.fonts
    dens = s.density
    lid = s.layout_id
    head = f"'BP-{f.heading}',{FALLBACK_STACK[f.heading]}"
    body = f"'BP-{f.body}',{FALLBACK_STACK[f.body]}"
    name = f"'BP-{f.name}',{FALLBACK_STACK[f.name]}"
    title_size = {"formal": 30, "academic": 28, "event": 34}[lid] * dens
    title_weight = {"formal": 600, "academic": 600, "event": 700}[lid]
    title_ls = {"formal": "0.06em", "academic": "0.03em", "event": "0.02em"}[lid]
    return f"""
{_font_css(s)}
@page {{ size: {PAGE_W}mm {PAGE_H}mm; margin: 0; }}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
html, body {{ background: #fff; -webkit-print-color-adjust: exact; print-color-adjust: exact; }}
body {{ font-family: {body}; color: {p.text}; font-variant-ligatures: none; font-feature-settings: "liga" 0, "clig" 0; }}
.page {{ position: relative; width: {PAGE_W}mm; height: {PAGE_H}mm; overflow: hidden; background: {p.background};
        break-after: page; page-break-after: always; }}
.page:last-child {{ break-after: auto; page-break-after: auto; }}
.decor, .bp-el {{ position: absolute; }}
.txt {{ display: flex; align-items: center; justify-content: center; text-align: center; line-height: 1.25; }}
.txt > span {{ display: block; max-width: 100%; }}
[data-el=org] {{ font-family: {head}; font-weight: 600; font-size: {13*dens:.2f}pt; color: {p.primary}; }}
[data-el=title] {{ font-family: {head}; font-weight: {title_weight}; font-size: {title_size:.2f}pt; color: {p.primary}; letter-spacing: {title_ls}; }}
[data-el=preamble] {{ font-size: {12*dens:.2f}pt; font-style: normal; }}
[data-el=name] {{ display: flex; align-items: center; justify-content: center; text-align: center; }}
[data-el=name] .nm {{ font-family: {name}; font-weight: 600; color: {p.primary}; display: inline-block; white-space: nowrap; line-height: 1.1; }}
.hw-line {{ position: absolute; left: 0; right: 0; bottom: 0; border-bottom: 0.4mm solid {p.text}; }}
[data-el=field_org] {{ font-size: {14*dens:.2f}pt; font-weight: 500; }}
[data-el=field_award] {{ font-size: {15*dens:.2f}pt; font-family: {head}; color: {p.accent}; font-weight: 600; }}
[data-el=body] {{ font-size: {12*dens:.2f}pt; line-height: 1.45; }}
.sig {{ display: flex; flex-direction: column; align-items: center; justify-content: flex-end; text-align: center; }}
.sig .img {{ height: 14mm; width: 60mm; display: flex; align-items: flex-end; justify-content: center; }}
.sig .img img {{ max-height: 14mm; max-width: 60mm; object-fit: contain; }}
.sig .ln {{ width: 60mm; border-top: 0.3mm solid {p.text}; margin-top: 1mm; }}
.sig .sn {{ font-weight: 700; font-size: {10.5*dens:.2f}pt; margin-top: 1mm; }}
.sig .st {{ font-size: {9.5*dens:.2f}pt; }}
[data-el=logo] {{ display: flex; align-items: center; justify-content: center; }}
[data-el=logo] img {{ max-width: 100%; max-height: 100%; object-fit: contain; }}
"""


def _fit_js(ctx: RenderContext) -> str:
    s = ctx.spec
    return """
window.__bp = (function(){
  const MAXPT=%s, MINPT=%s, TWO=%s;
  const PT=96/72;
  function fitAll(){
    const res=[];
    document.querySelectorAll('.page').forEach((pg,i)=>{
      const el=pg.querySelector('[data-el=name] .nm'); if(!el){return;}
      const box=el.parentElement; const bw=box.clientWidth, bh=box.clientHeight;
      function apply(sz){el.style.fontSize=sz+'pt';}
      function fits(){
        if(el.style.whiteSpace==='normal'){return el.scrollWidth<=bw+0.5 && el.getBoundingClientRect().height<=bh+0.5;}
        const r=el.getBoundingClientRect(); return r.width<=bw+0.5 && r.height<=bh+0.5;
      }
      el.style.whiteSpace='nowrap'; el.style.maxWidth='none'; let sz=MAXPT; apply(sz);
      while(!fits() && sz>MINPT){sz=Math.max(MINPT,sz-0.5); apply(sz);}
      let lines=1;
      if(!fits() && TWO){
        el.style.whiteSpace='normal'; el.style.maxWidth=bw+'px'; el.style.display='block'; el.style.textAlign='center';
        sz=MAXPT; apply(sz);
        while(!fits() && sz>MINPT){sz=Math.max(MINPT,sz-0.5); apply(sz);}
      }
      const lh=parseFloat(getComputedStyle(el).lineHeight)||sz*PT*1.1;
      lines=Math.max(1,Math.round(el.getBoundingClientRect().height/lh));
      res.push({page:i+1,size:sz,lines:lines,adjusted:sz<MAXPT-0.01,overflow:!fits()});
    });
    return res;
  }
  function contentRect(el){
    const rects=[];
    const w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT|NodeFilter.SHOW_ELEMENT);
    let n;
    while((n=w.nextNode())){
      if(n.nodeType===3){ if(!n.textContent.trim()) continue; const r=document.createRange(); r.selectNodeContents(n); for(const q of r.getClientRects()){rects.push(q);} }
      else if(n.tagName==='IMG'){rects.push(n.getBoundingClientRect());}
    }
    if(!rects.length) return null;
    let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
    rects.forEach(q=>{x0=Math.min(x0,q.left);y0=Math.min(y0,q.top);x1=Math.max(x1,q.right);y1=Math.max(y1,q.bottom);});
    return {x0,y0,x1,y1};
  }
  function inter(a,b){const w=Math.min(a.x1,b.x1)-Math.max(a.x0,b.x0), h=Math.min(a.y1,b.y1)-Math.max(a.y0,b.y0); return w>1&&h>1;}
  function boxRect(el){const r=el.getBoundingClientRect();return {x0:r.left,y0:r.top,x1:r.right,y1:r.bottom};}
  function geometry(){
    const issues=[];
    document.querySelectorAll('.page').forEach((pg,i)=>{
      const pr=boxRect(pg); const pn=i+1;
      const els=[...pg.querySelectorAll('.bp-el')];
      const info=els.map(el=>({el,id:el.dataset.el,reserved:!!el.dataset.reserved,
        c:contentRect(el)||(el.dataset.reserved?boxRect(el):null), box:boxRect(el)}));
      info.forEach(a=>{ if(!a.c) return;
        if(a.c.x0<pr.x0-0.5||a.c.y0<pr.y0-0.5||a.c.x1>pr.x1+0.5||a.c.y1>pr.y1+0.5)
          issues.push({page:pn,code:'CONTENT_OUTSIDE_PAGE',el:a.id});
      });
      for(let x=0;x<info.length;x++)for(let y=x+1;y<info.length;y++){
        const a=info[x],b=info[y]; if(!a.c||!b.c) continue;
        if(a.reserved||b.reserved) continue;
        if(inter(a.c,b.c)) issues.push({page:pn,code:'ESSENTIAL_ELEMENT_OVERLAP',el:a.id,other:b.id});
      }
      info.filter(a=>a.reserved).forEach(r=>{
        info.forEach(o=>{ if(o===r||!o.c) return; if(inter(r.box,o.c)) issues.push({page:pn,code:'HANDWRITING_AREA_OBSTRUCTED',el:o.id,other:r.id}); });
        pg.querySelectorAll('.decor:not([data-frame])').forEach(d=>{ if(inter(r.box,boxRect(d))) issues.push({page:pn,code:'HANDWRITING_AREA_OBSTRUCTED',el:'decor',other:r.id}); });
        const M=14*96/25.4; if(r.box.x0<pr.x0+M||r.box.x1>pr.x1-M||r.box.y0<pr.y0+M||r.box.y1>pr.y1-M) issues.push({page:pn,code:'CONTENT_OUTSIDE_PAGE',el:r.id});
      });
      pg.querySelectorAll('img').forEach(im=>{ if(!(im.complete&&im.naturalWidth>0)) issues.push({page:pn,code:'ASSET_LOAD_FAILURE',el:im.parentElement.dataset.el||'img'}); });
    });
    const bad=[...document.fonts].filter(f=>f.status==='error').map(f=>f.family);
    if(bad.length) issues.push({page:0,code:'ASSET_LOAD_FAILURE',el:'font:'+bad.join(',')});
    return issues;
  }
  return {fitAll,geometry};
})();
""" % (s.name_font_max_pt, s.name_font_min_pt, "true" if s.allow_two_lines else "false")


def build_document(ctx: RenderContext, doc_title: str) -> str:
    s, e = ctx.spec, ctx.event
    blank = ctx.blank
    nw = blank.width_mm if blank else s.name_box_width_mm
    nh = blank.height_mm if blank else s.name_box_height_mm
    g = geometry(nw, nh)
    sigs = list(zip(e.signatories, signatory_rects(len(e.signatories))))
    body_txt = render_body_text(s, e)
    decor = _decor(s)
    pages = []
    for i, pd in enumerate(ctx.pages):
        h = [f'<section class="page" data-page="{i+1}">', decor]
        logo_url = ctx.asset_urls.get(e.logo_asset_id or "")
        if logo_url:
            h.append(f'<div class="bp-el" data-el="logo" data-essential="1" style="{_rect_style(g["logo"])}"><img src="{esc(logo_url)}" alt=""></div>')
        def txt(key, text):
            if text:
                h.append(f'<div class="bp-el txt" data-el="{key}" data-essential="1" style="{_rect_style(g[key])}"><span>{esc(text)}</span></div>')
        txt("org", e.organisation)
        txt("title", e.cert_type)
        txt("preamble", s.preamble_text)
        if blank:
            line = '<div class="hw-line"></div>' if blank.line else ""
            h.append(f'<div class="bp-el" data-el="name" data-reserved="1" style="{_rect_style(g["name"])}">{line}</div>')
            for fld, key in (("organisation", "field_org"), ("award", "field_award")):
                pol = blank.optional_fields.get(fld)
                if not pol or pol.mode == "omit":
                    continue
                if pol.mode == "fixed":
                    txt(key, pol.fixed_text)
                else:  # handwriting
                    line2 = '<div class="hw-line"></div>' if blank.line else ""
                    h.append(f'<div class="bp-el" data-el="{key}" data-reserved="1" style="{_rect_style(g[key])}">{line2}</div>')
        else:
            h.append(f'<div class="bp-el" data-el="name" data-essential="1" style="{_rect_style(g["name"])}"><span class="nm">{esc(pd.name or "")}</span></div>')
            txt("field_org", pd.organisation or "")
            txt("field_award", pd.award or "")
        txt("body", body_txt)
        for k, (sg, r) in enumerate(sigs):
            img = ""
            url = ctx.asset_urls.get(sg.signature_asset_id or "")
            if url:
                img = f'<img src="{esc(url)}" alt="">'
            h.append(
                f'<div class="bp-el sig" data-el="sig{k+1}" data-essential="1" style="{_rect_style(r)}">'
                f'<div class="img">{img}</div><div class="ln"></div>'
                f'<div class="sn">{esc(sg.name)}</div><div class="st">{esc(sg.title)}</div></div>'
            )
        h.append("</section>")
        pages.append("".join(h))
    return (
        '<!doctype html><html lang="en"><head><meta charset="utf-8">'
        f"<title>{esc(doc_title)}</title><style>{_css(ctx)}</style></head><body>"
        + "".join(pages) + f"<script>{_fit_js(ctx)}</script></body></html>"
    )
