import { useEffect, useState } from "react";
import { route } from "./api";
import Dashboard from "./pages/Dashboard";
import ProjectPage from "./pages/ProjectPage";
import CheckPage from "./pages/CheckPage";

export default function App() {
  const [r, setR] = useState(route());
  useEffect(() => {
    const h = () => setR(route());
    window.addEventListener("hashchange", h);
    return () => window.removeEventListener("hashchange", h);
  }, []);
  return (
    <div className="app">
      <header className="top">
        <a href="#/" className="brand">BatchProof</a>
        <span className="tag">certificates you can check before you print</span>
        <nav><a href="#/">Projects</a></nav>
      </header>
      <main>
        {r[0] === "p" && r[1] ? <ProjectPage id={r[1]} tab={r[2] || "design"} key={r[1]} />
          : r[0] === "check" && r[1] ? <CheckPage id={r[1]} key={r[1]} />
          : <Dashboard />}
      </main>
      <footer className="foot">
        Local-first. Your recipient lists and images stay on this computer. “Checked” means the implemented checks passed
        against the inputs you confirmed — it does not verify identity, event facts or legal validity.
      </footer>
    </div>
  );
}
