import { useCallback, useEffect, useState } from "react";
import { A, api, go } from "../api";
import { Banner } from "../ui";
import DesignTab from "../components/DesignTab";
import SourcePanel from "../components/SourcePanel";
import ExportTab from "../components/ExportTab";
import ReviewTab from "../components/ReviewTab";

const TABS: [string, string][] = [["design", "1 · Design"], ["recipients", "2 · Recipients"], ["export", "3 · Export"], ["review", "4 · Batch review"]];

export default function ProjectPage({ id, tab }: { id: string; tab: string }) {
  const [p, setP] = useState<A>(null);
  const [err, setErr] = useState("");
  const reload = useCallback(async () => {
    try { setP(await api("/projects/" + id)); setErr(""); } catch (e: A) { setErr(e.message); }
  }, [id]);
  useEffect(() => { reload(); }, [reload]);
  if (err) return <Banner kind="bad">{err}</Banner>;
  if (!p) return <p>Loading…</p>;
  return (
    <section>
      <div className="row between">
        <h1>{p.title}</h1>
        {p.is_demo && <span className="chip muted">DEMO · synthetic data</span>}
      </div>
      <div className="tabs" role="tablist">
        {TABS.map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? "on" : ""} onClick={() => go(`p/${id}/${k}`)}>{l}</button>)}
      </div>
      {tab === "design" && <DesignTab p={p} reload={reload} />}
      {tab === "recipients" && <SourcePanel p={p} reload={reload} />}
      {tab === "export" && <ExportTab p={p} reload={reload} />}
      {tab === "review" && <ReviewTab p={p} reload={reload} />}
    </section>
  );
}
