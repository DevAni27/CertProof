import { useEffect, useState } from "react";
import { A, api, go } from "../api";
import { Banner } from "../ui";

export default function Dashboard() {
  const [projects, setProjects] = useState<A[]>([]);
  const [ai, setAi] = useState<A>(null);
  const [err, setErr] = useState("");
  const load = () => api("/projects").then(setProjects).catch((e) => setErr(e.message));
  useEffect(() => {
    load();
    api("/ai/status").then(setAi).catch(() => setAi(null));
  }, []);

  const create = async (body: A, to: (id: string) => string) => {
    try {
      const p = await api("/projects", { json: body });
      go(to(p.id));
    } catch (e: A) { setErr(e.message); }
  };
  const del = async (p: A) => {
    if (!confirm(`Delete "${p.title}" and all its files (recipients, images, PDFs)? This cannot be undone.`)) return;
    await api("/projects/" + p.id, { method: "DELETE" });
    load();
  };

  return (
    <section>
      <h1>Projects</h1>
      {err && <Banner kind="bad">{err}</Banner>}
      <div className="cards">
        <button className="card action" onClick={() => create({ title: "New certificate project" }, (id) => `p/${id}/design`)}>
          <strong>New certificate project</strong><span>Describe the event, add branding and recipients, then generate a checked batch — or blank-name certificates to fill by hand.</span>
        </button>
        <button className="card action" onClick={() => create({ title: "Check an existing batch", kind: "check" }, (id) => `check/${id}`)}>
          <strong>Check an existing batch</strong><span>Upload your spreadsheet and a separately made searchable PDF. BatchProof reports missing, repeated, unexpected and altered certificates.</span>
        </button>
        <button className="card action" onClick={() => create({ title: "Demo", sample: true }, (id) => `p/${id}/design`)}>
          <strong>Load the sample project</strong><span>Synthetic demo data (fictional hackathon). Clearly labelled; safe to delete.</span>
        </button>
      </div>

      <h2>Reopen a local project</h2>
      {projects.length === 0 ? <p className="empty">No projects yet. Start with a new project or load the sample.</p> : (
        <table className="tbl">
          <thead><tr><th>Title</th><th>Type</th><th>Recipients</th><th>Updated</th><th /></tr></thead>
          <tbody>
            {projects.map((p) => (
              <tr key={p.id}>
                <td><a href={p.kind === "check" ? `#/check/${p.id}` : `#/p/${p.id}/design`}>{p.title}</a> {p.is_demo && <span className="chip muted">DEMO · synthetic</span>}</td>
                <td>{p.kind === "check" ? "Check existing batch" : "Generate"}</td>
                <td>{p.recipients}</td>
                <td>{new Date(p.updated_at).toLocaleString()}</td>
                <td><button className="btn small danger" onClick={() => del(p)}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <h2>Local AI</h2>
      {!ai ? <Banner kind="warn">Could not read AI status. The app still works manually.</Banner>
        : ai.reachable && ai.model_installed ? <Banner kind="ok">Ollama is running and model <code>{ai.model}</code> is installed. AI features are optional; everything also works manually.</Banner>
        : <Banner kind="warn">{ai.error} AI suggestions are unavailable until then; manual design and rule-based mapping still work.</Banner>}
      {ai?.reachable && <button className="btn small" onClick={() => api("/ai/unload", { method: "POST" }).then(() => alert("Asked Ollama to unload the model from memory."))}>Unload model from memory</button>}
    </section>
  );
}
